import { ReportService } from './service'
import express from 'express'
import { validateToken } from '../utils/authentication-helper'

const reportRouter = express.Router()
const reportService = new ReportService()

reportRouter
  .post('/interactions', validateToken, reportService.getOpenOrClosedInteractions.bind(reportService))
  .post('/chats', validateToken, reportService.getChatInteractions.bind(reportService))

module.exports = reportRouter
