
export const html = (id, userName, type) => {
  const html =
          'Dear ' + userName + ',' +
            type + ' has been assigned to you.' + 'Complaint id is ' + id +
          ' For more information please login to AIOS. Thank you'
  return html
}
