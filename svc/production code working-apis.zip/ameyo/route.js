import express from 'express'

const router = express.Router()

router.post('/')

module.exports = router
