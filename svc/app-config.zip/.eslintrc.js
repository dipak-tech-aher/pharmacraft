module.exports = {
  extends: 'standard',
  rules: {
    'no-prototype-builtins': 0,
    'no-useless-escape': 0
  }
}
